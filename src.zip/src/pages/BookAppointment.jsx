import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { useAuth } from "../context/AuthContext";
import "../styles/bookAppointment.css";

function BookAppointment() {
  const location = useLocation();
  const navigate = useNavigate();

  const { user } = useAuth();

  const doctor = location.state?.doctor;

  const [appointmentDate, setAppointmentDate] = useState("");
  const [appointmentTime, setAppointmentTime] = useState("");
  const [loading, setLoading] = useState(false);

  if (!doctor) {
    return (
      <div className="appointment-page">
        <div className="appointment-form">
          <h2>No doctor selected.</h2>
        </div>
      </div>
    );
  }

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!user) {
      alert("Please login first.");
      return;
    }

    if (!appointmentDate || !appointmentTime) {
      alert("Please fill all fields.");
      return;
    }

    const today = new Date().toISOString().split("T")[0];

    if (appointmentDate < today) {
      alert("You cannot book an appointment in the past.");
      return;
    }

    setLoading(true);

    try {
      // Check if doctor already has an appointment
      const { data: existingAppointment, error: checkError } =
        await supabase
          .from("appointments")
          .select("id")
          .eq("doctor_id", doctor.id)
          .eq("appointment_date", appointmentDate)
          .eq("appointment_time", appointmentTime)
          .maybeSingle();

      if (checkError) {
        setLoading(false);
        alert(checkError.message);
        return;
      }

      if (existingAppointment) {
        setLoading(false);
        alert("This time slot is already booked.");
        return;
      }

      // Insert appointment
      const { error } = await supabase
        .from("appointments")
        .insert([
          {
            patient_id: user.id,
            doctor_id: doctor.id,
            appointment_date: appointmentDate,
            appointment_time: appointmentTime,
            status: "Pending",
          },
        ]);

      setLoading(false);

      if (error) {
        console.error(error);
        alert(error.message);
        return;
      }

      alert("Appointment booked successfully!");

      navigate("/patient/dashboard");
    } catch (err) {
      console.error(err);
      setLoading(false);
      alert("Something went wrong.");
    }
  };

  return (
    <div className="appointment-page">
      <form
        className="appointment-form"
        onSubmit={handleSubmit}
      >
        <h2>Book Appointment</h2>

        <label>Doctor Name</label>
        <input
          type="text"
          value={doctor.full_name}
          readOnly
        />

        <label>Specialty</label>
        <input
          type="text"
          value={doctor.specialty || "Not Added"}
          readOnly
        />

        <label>Select Date</label>
        <input
          type="date"
          value={appointmentDate}
          min={new Date().toISOString().split("T")[0]}
          onChange={(e) =>
            setAppointmentDate(e.target.value)
          }
          required
        />

        <label>Select Time</label>
        <input
          type="time"
          value={appointmentTime}
          onChange={(e) =>
            setAppointmentTime(e.target.value)
          }
          required
        />

        <button
          type="submit"
          disabled={loading}
        >
          {loading ? "Booking..." : "Book Appointment"}
        </button>
      </form>
    </div>
  );
}

export default BookAppointment;